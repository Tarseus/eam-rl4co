from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from zipfile import ZipFile


def _shape_counts(target_dir: Path) -> dict[str, int]:
    counts = Counter(path.stem.split("_")[0] for path in target_dir.glob("*.jsp"))
    return {shape: int(count) for shape, count in sorted(counts.items())}


def _extract_if_needed(zip_path: Path, required_glob: str = "*.jsp") -> dict[str, object]:
    target_dir = zip_path.parent
    existing = sorted(target_dir.glob(required_glob))
    extracted = False
    if not existing:
        with ZipFile(zip_path, "r") as zf:
            zf.extractall(target_dir)
        extracted = True
        existing = sorted(target_dir.glob(required_glob))
    return {
        "zip_path": zip_path.as_posix(),
        "target_dir": target_dir.as_posix(),
        "extracted": extracted,
        "count": len(existing),
        "shape_counts": _shape_counts(target_dir),
    }


def prepare_bopo_jsp(root_dir: Path) -> dict[str, object]:
    bopo_root = root_dir / "BOPO" / "JSP"
    results = {
        "train": _extract_if_needed(bopo_root / "dataset5k" / "dataset5k.zip"),
        "validation": _extract_if_needed(
            bopo_root / "benchmarks" / "validation" / "validation.zip"
        ),
    }
    for name in ("TA", "LA", "DMU"):
        files = sorted((bopo_root / "benchmarks" / name).glob("*.jsp"))
        results[name] = {
            "target_dir": (bopo_root / "benchmarks" / name).as_posix(),
            "count": len(files),
            "shape_counts": _shape_counts(bopo_root / "benchmarks" / name),
        }
    return results


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare BOPO/JSP dataset and validation archives.")
    parser.add_argument(
        "--root-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Repository root directory.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print machine-readable JSON only.",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    summary = prepare_bopo_jsp(args.root_dir.resolve())
    if args.json:
        print(json.dumps(summary, ensure_ascii=True))
        return 0

    for name, payload in summary.items():
        pieces = [f"{name}: dir={payload['target_dir']}", f"count={payload['count']}"]
        if "zip_path" in payload:
            pieces.append(f"zip={payload['zip_path']}")
            pieces.append(f"extracted={payload['extracted']}")
        print(" | ".join(pieces), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
