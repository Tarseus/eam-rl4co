from .model import PolyNet
